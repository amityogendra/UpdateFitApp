import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Button } from "@/components/ui/button"
import { Award, Dumbbell, Flame, Gift, Heart, TrendingUp, Trophy, Zap, Apple } from "lucide-react"

export default function Dashboard() {
  return (
    <div className="flex-1 space-y-4 p-4 md:p-8 pt-6">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold tracking-tight">Dashboard</h2>
        <div className="flex items-center space-x-2">
          <Button className="bg-blue-600 hover:bg-blue-700">Start Workout</Button>
        </div>
      </div>

      {/* Daily Progress */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Steps</CardTitle>
            <Flame className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">7,842</div>
            <Progress value={78} className="h-2 mt-2" />
            <p className="text-xs text-muted-foreground mt-2">78% of daily goal (10,000)</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Calories Burned</CardTitle>
            <Flame className="h-4 w-4 text-orange-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">385</div>
            <Progress value={55} className="h-2 mt-2" />
            <p className="text-xs text-muted-foreground mt-2">55% of daily goal (700)</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Minutes</CardTitle>
            <Zap className="h-4 w-4 text-yellow-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">32</div>
            <Progress value={53} className="h-2 mt-2" />
            <p className="text-xs text-muted-foreground mt-2">53% of daily goal (60)</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Rewards Points</CardTitle>
            <Gift className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">245</div>
            <div className="flex items-center mt-2">
              <Award className="h-4 w-4 text-blue-600 mr-1" />
              <span className="text-xs text-blue-600 font-medium">+45 points today</span>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Today's Plan */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
        <Card className="col-span-4">
          <CardHeader>
            <CardTitle>Today's Plan</CardTitle>
            <CardDescription>Your personalized workout and nutrition plan for today</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-start space-x-4">
                <div className="bg-blue-100 p-2 rounded-md">
                  <Dumbbell className="h-5 w-5 text-blue-600" />
                </div>
                <div className="space-y-1">
                  <h4 className="font-semibold">Upper Body Strength</h4>
                  <p className="text-sm text-muted-foreground">30 min • 5 exercises • 250 calories</p>
                  <div className="flex space-x-2 mt-2">
                    <Button variant="outline" size="sm">
                      View Details
                    </Button>
                    <Button size="sm" className="bg-blue-600 hover:bg-blue-700">
                      Start
                    </Button>
                  </div>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="bg-green-100 p-2 rounded-md">
                  <Apple className="h-5 w-5 text-green-600" />
                </div>
                <div className="space-y-1">
                  <h4 className="font-semibold">Protein-Rich Lunch</h4>
                  <p className="text-sm text-muted-foreground">Grilled chicken salad with quinoa • 450 calories</p>
                  <div className="flex space-x-2 mt-2">
                    <Button variant="outline" size="sm">
                      View Recipe
                    </Button>
                  </div>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="bg-purple-100 p-2 rounded-md">
                  <Heart className="h-5 w-5 text-purple-600" />
                </div>
                <div className="space-y-1">
                  <h4 className="font-semibold">Evening Cardio</h4>
                  <p className="text-sm text-muted-foreground">20 min • Jogging • 200 calories</p>
                  <div className="flex space-x-2 mt-2">
                    <Button variant="outline" size="sm">
                      View Details
                    </Button>
                    <Button size="sm" className="bg-blue-600 hover:bg-blue-700">
                      Start
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Rewards Section */}
        <Card className="col-span-3">
          <CardHeader>
            <CardTitle>Rewards</CardTitle>
            <CardDescription>Complete challenges to earn rewards</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="bg-blue-50 p-4 rounded-lg border border-blue-100">
                <div className="flex justify-between items-center">
                  <div className="flex items-center space-x-2">
                    <Trophy className="h-5 w-5 text-blue-600" />
                    <h4 className="font-semibold">Weekly Challenge</h4>
                  </div>
                  <span className="text-sm font-medium text-blue-600">+100 pts</span>
                </div>
                <p className="text-sm mt-2">Complete 5 workouts this week</p>
                <Progress value={60} className="h-2 mt-3" />
                <p className="text-xs text-muted-foreground mt-1">3/5 completed</p>
              </div>

              <div className="bg-green-50 p-4 rounded-lg border border-green-100">
                <div className="flex justify-between items-center">
                  <div className="flex items-center space-x-2">
                    <Gift className="h-5 w-5 text-green-600" />
                    <h4 className="font-semibold">Step Challenge</h4>
                  </div>
                  <span className="text-sm font-medium text-green-600">₹50 Cashback</span>
                </div>
                <p className="text-sm mt-2">Reach 70,000 steps this week</p>
                <Progress value={45} className="h-2 mt-3" />
                <p className="text-xs text-muted-foreground mt-1">31,500/70,000 steps</p>
              </div>

              <Button className="w-full bg-blue-600 hover:bg-blue-700">View All Rewards</Button>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Progress Tracking */}
      <Card>
        <CardHeader>
          <CardTitle>Your Progress</CardTitle>
          <CardDescription>Track your fitness journey over time</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="h-[200px] w-full flex items-center justify-center">
            <div className="flex items-center space-x-2">
              <TrendingUp className="h-5 w-5 text-blue-600" />
              <span className="text-sm text-muted-foreground">
                Your fitness activity is trending up by 12% this week
              </span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
