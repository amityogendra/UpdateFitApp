"use client"

import { Home, Dumbbell, Apple, Gift, User } from "lucide-react"
import { usePathname, useRouter } from "next/navigation"

export function MobileNav() {
  const pathname = usePathname()
  const router = useRouter()

  return (
    <div className="fixed bottom-0 left-0 z-50 w-full h-16 bg-white border-t border-gray-200">
      <div className="grid h-full max-w-lg grid-cols-5 mx-auto">
        <button
          type="button"
          className="inline-flex flex-col items-center justify-center px-5 hover:bg-gray-50 group"
          onClick={() => router.push("/")}
        >
          <Home className={`w-6 h-6 ${pathname === "/" ? "text-blue-600" : "text-gray-500"}`} />
          <span className="text-xs text-gray-500 group-hover:text-blue-600">Home</span>
        </button>
        <button
          type="button"
          className="inline-flex flex-col items-center justify-center px-5 hover:bg-gray-50 group"
          onClick={() => router.push("/workouts")}
        >
          <Dumbbell className="w-6 h-6 text-gray-500 group-hover:text-blue-600" />
          <span className="text-xs text-gray-500 group-hover:text-blue-600">Workouts</span>
        </button>
        <button
          type="button"
          className="inline-flex flex-col items-center justify-center px-5 hover:bg-gray-50 group"
          onClick={() => router.push("/nutrition")}
        >
          <Apple className="w-6 h-6 text-gray-500 group-hover:text-blue-600" />
          <span className="text-xs text-gray-500 group-hover:text-blue-600">Nutrition</span>
        </button>
        <button
          type="button"
          className="inline-flex flex-col items-center justify-center px-5 hover:bg-gray-50 group"
          onClick={() => router.push("/rewards")}
        >
          <Gift className="w-6 h-6 text-gray-500 group-hover:text-blue-600" />
          <span className="text-xs text-gray-500 group-hover:text-blue-600">Rewards</span>
        </button>
        <button
          type="button"
          className="inline-flex flex-col items-center justify-center px-5 hover:bg-gray-50 group"
          onClick={() => router.push("/profile")}
        >
          <User className="w-6 h-6 text-gray-500 group-hover:text-blue-600" />
          <span className="text-xs text-gray-500 group-hover:text-blue-600">Profile</span>
        </button>
      </div>
    </div>
  )
}
