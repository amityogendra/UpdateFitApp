import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import { Button } from "@/components/ui/button"
import { Award, Gift, Star, Trophy, Zap } from "lucide-react"

export default function Rewards() {
  return (
    <div className="flex-1 space-y-4 p-4 md:p-8 pt-6">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold tracking-tight">Rewards</h2>
        <div className="flex items-center space-x-2">
          <div className="flex items-center bg-blue-100 px-3 py-1 rounded-full">
            <Gift className="h-4 w-4 text-blue-600 mr-2" />
            <span className="font-medium text-blue-600">245 points</span>
          </div>
        </div>
      </div>

      <Tabs defaultValue="challenges" className="space-y-4">
        <TabsList>
          <TabsTrigger value="challenges">Challenges</TabsTrigger>
          <TabsTrigger value="rewards">Available Rewards</TabsTrigger>
          <TabsTrigger value="history">Reward History</TabsTrigger>
        </TabsList>

        <TabsContent value="challenges" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {/* Daily Challenge */}
            <Card>
              <CardHeader className="bg-gradient-to-r from-blue-500 to-blue-600 text-white rounded-t-lg">
                <div className="flex justify-between items-center">
                  <CardTitle className="text-lg">Daily Challenge</CardTitle>
                  <Zap className="h-5 w-5" />
                </div>
                <CardDescription className="text-blue-100">Complete today for bonus points</CardDescription>
              </CardHeader>
              <CardContent className="pt-6">
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <div className="flex items-center space-x-2">
                      <div className="bg-blue-100 p-2 rounded-full">
                        <Trophy className="h-4 w-4 text-blue-600" />
                      </div>
                      <div>
                        <h4 className="font-medium">10,000 Steps</h4>
                        <p className="text-sm text-muted-foreground">Walk 10,000 steps today</p>
                      </div>
                    </div>
                    <span className="font-medium text-blue-600">+25 pts</span>
                  </div>
                  <Progress value={78} className="h-2" />
                  <p className="text-xs text-muted-foreground">7,842/10,000 steps</p>
                </div>
              </CardContent>
              <CardFooter className="border-t pt-4">
                <Button className="w-full bg-blue-600 hover:bg-blue-700">Track Progress</Button>
              </CardFooter>
            </Card>

            {/* Weekly Challenge */}
            <Card>
              <CardHeader className="bg-gradient-to-r from-purple-500 to-purple-600 text-white rounded-t-lg">
                <div className="flex justify-between items-center">
                  <CardTitle className="text-lg">Weekly Challenge</CardTitle>
                  <Award className="h-5 w-5" />
                </div>
                <CardDescription className="text-purple-100">5 days remaining</CardDescription>
              </CardHeader>
              <CardContent className="pt-6">
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <div className="flex items-center space-x-2">
                      <div className="bg-purple-100 p-2 rounded-full">
                        <Trophy className="h-4 w-4 text-purple-600" />
                      </div>
                      <div>
                        <h4 className="font-medium">5 Workouts</h4>
                        <p className="text-sm text-muted-foreground">Complete 5 workouts this week</p>
                      </div>
                    </div>
                    <span className="font-medium text-purple-600">+100 pts</span>
                  </div>
                  <Progress value={60} className="h-2" />
                  <p className="text-xs text-muted-foreground">3/5 workouts</p>
                </div>
              </CardContent>
              <CardFooter className="border-t pt-4">
                <Button className="w-full bg-purple-600 hover:bg-purple-700">Track Progress</Button>
              </CardFooter>
            </Card>

            {/* Monthly Challenge */}
            <Card>
              <CardHeader className="bg-gradient-to-r from-green-500 to-green-600 text-white rounded-t-lg">
                <div className="flex justify-between items-center">
                  <CardTitle className="text-lg">Monthly Challenge</CardTitle>
                  <Star className="h-5 w-5" />
                </div>
                <CardDescription className="text-green-100">18 days remaining</CardDescription>
              </CardHeader>
              <CardContent className="pt-6">
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <div className="flex items-center space-x-2">
                      <div className="bg-green-100 p-2 rounded-full">
                        <Gift className="h-4 w-4 text-green-600" />
                      </div>
                      <div>
                        <h4 className="font-medium">Burn 9000 Calories</h4>
                        <p className="text-sm text-muted-foreground">Total for the month</p>
                      </div>
                    </div>
                    <span className="font-medium text-green-600">₹100</span>
                  </div>
                  <Progress value={35} className="h-2" />
                  <p className="text-xs text-muted-foreground">3,150/9,000 calories</p>
                </div>
              </CardContent>
              <CardFooter className="border-t pt-4">
                <Button className="w-full bg-green-600 hover:bg-green-700">Track Progress</Button>
              </CardFooter>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Special Challenges</CardTitle>
              <CardDescription>Complete these challenges to earn bigger rewards</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="flex items-center space-x-4">
                    <div className="bg-amber-100 p-3 rounded-full">
                      <Trophy className="h-6 w-6 text-amber-600" />
                    </div>
                    <div>
                      <h4 className="font-medium">30-Day Transformation</h4>
                      <p className="text-sm text-muted-foreground">Complete all daily workouts for 30 days</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-medium text-amber-600">₹500</div>
                    <div className="text-xs text-muted-foreground">8 days completed</div>
                  </div>
                </div>

                <div className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="flex items-center space-x-4">
                    <div className="bg-blue-100 p-3 rounded-full">
                      <Star className="h-6 w-6 text-blue-600" />
                    </div>
                    <div>
                      <h4 className="font-medium">Invite Friends Challenge</h4>
                      <p className="text-sm text-muted-foreground">Invite 5 friends to join the app</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-medium text-blue-600">Free Month</div>
                    <div className="text-xs text-muted-foreground">2/5 invites sent</div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="rewards" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            <Card>
              <CardHeader>
                <CardTitle>Premium Membership</CardTitle>
                <CardDescription>1 Month Free</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-center py-4">
                  <div className="bg-blue-100 p-4 rounded-full inline-flex mb-4">
                    <Gift className="h-8 w-8 text-blue-600" />
                  </div>
                  <div className="text-2xl font-bold text-blue-600">300 points</div>
                </div>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-center">
                    <Zap className="h-4 w-4 text-blue-600 mr-2" />
                    <span>Access to all premium workouts</span>
                  </li>
                  <li className="flex items-center">
                    <Zap className="h-4 w-4 text-blue-600 mr-2" />
                    <span>Personalized nutrition plans</span>
                  </li>
                  <li className="flex items-center">
                    <Zap className="h-4 w-4 text-blue-600 mr-2" />
                    <span>Ad-free experience</span>
                  </li>
                </ul>
              </CardContent>
              <CardFooter>
                <Button className="w-full bg-blue-600 hover:bg-blue-700">Redeem</Button>
              </CardFooter>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Cash Reward</CardTitle>
                <CardDescription>Direct to your account</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-center py-4">
                  <div className="bg-green-100 p-4 rounded-full inline-flex mb-4">
                    <Award className="h-8 w-8 text-green-600" />
                  </div>
                  <div className="text-2xl font-bold text-green-600">500 points</div>
                </div>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-center">
                    <Zap className="h-4 w-4 text-green-600 mr-2" />
                    <span>₹100 cash reward</span>
                  </li>
                  <li className="flex items-center">
                    <Zap className="h-4 w-4 text-green-600 mr-2" />
                    <span>Transferred to your account</span>
                  </li>
                  <li className="flex items-center">
                    <Zap className="h-4 w-4 text-green-600 mr-2" />
                    <span>Processing time: 2-3 days</span>
                  </li>
                </ul>
              </CardContent>
              <CardFooter>
                <Button className="w-full bg-green-600 hover:bg-green-700">Redeem</Button>
              </CardFooter>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Fitness Gear Discount</CardTitle>
                <CardDescription>Partner store voucher</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-center py-4">
                  <div className="bg-purple-100 p-4 rounded-full inline-flex mb-4">
                    <Gift className="h-8 w-8 text-purple-600" />
                  </div>
                  <div className="text-2xl font-bold text-purple-600">200 points</div>
                </div>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-center">
                    <Zap className="h-4 w-4 text-purple-600 mr-2" />
                    <span>20% off at FitGear Store</span>
                  </li>
                  <li className="flex items-center">
                    <Zap className="h-4 w-4 text-purple-600 mr-2" />
                    <span>Valid for 3 months</span>
                  </li>
                  <li className="flex items-center">
                    <Zap className="h-4 w-4 text-purple-600 mr-2" />
                    <span>Online and in-store</span>
                  </li>
                </ul>
              </CardContent>
              <CardFooter>
                <Button className="w-full bg-purple-600 hover:bg-purple-700">Redeem</Button>
              </CardFooter>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="history">
          <Card>
            <CardHeader>
              <CardTitle>Reward History</CardTitle>
              <CardDescription>Your previously redeemed rewards</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="flex items-center space-x-4">
                    <div className="bg-gray-100 p-2 rounded-full">
                      <Gift className="h-5 w-5 text-gray-600" />
                    </div>
                    <div>
                      <h4 className="font-medium">Premium Membership</h4>
                      <p className="text-xs text-muted-foreground">Redeemed on May 1, 2025</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-medium">300 points</div>
                    <div className="text-xs text-green-600">Active</div>
                  </div>
                </div>

                <div className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="flex items-center space-x-4">
                    <div className="bg-gray-100 p-2 rounded-full">
                      <Award className="h-5 w-5 text-gray-600" />
                    </div>
                    <div>
                      <h4 className="font-medium">Cash Reward</h4>
                      <p className="text-xs text-muted-foreground">Redeemed on April 15, 2025</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-medium">500 points</div>
                    <div className="text-xs text-green-600">₹100 Transferred</div>
                  </div>
                </div>

                <div className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="flex items-center space-x-4">
                    <div className="bg-gray-100 p-2 rounded-full">
                      <Gift className="h-5 w-5 text-gray-600" />
                    </div>
                    <div>
                      <h4 className="font-medium">Fitness Gear Discount</h4>
                      <p className="text-xs text-muted-foreground">Redeemed on March 22, 2025</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-medium">200 points</div>
                    <div className="text-xs text-amber-600">Expires June 22, 2025</div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
