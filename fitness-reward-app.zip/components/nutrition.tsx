import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Apple, ArrowRight, Clock, Coffee, Flame, Utensils } from "lucide-react"

export default function Nutrition() {
  return (
    <div className="flex-1 space-y-4 p-4 md:p-8 pt-6">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold tracking-tight">Nutrition</h2>
        <div className="flex items-center space-x-2">
          <Button className="bg-blue-600 hover:bg-blue-700">Log Meal</Button>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Calories</CardTitle>
            <Flame className="h-4 w-4 text-orange-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">1,245 / 2,100</div>
            <p className="text-xs text-muted-foreground mt-2">855 calories remaining</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Protein</CardTitle>
            <div className="h-4 w-4 rounded-full bg-blue-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">65g / 120g</div>
            <p className="text-xs text-muted-foreground mt-2">55g remaining</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Carbs</CardTitle>
            <div className="h-4 w-4 rounded-full bg-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">145g / 240g</div>
            <p className="text-xs text-muted-foreground mt-2">95g remaining</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Fat</CardTitle>
            <div className="h-4 w-4 rounded-full bg-yellow-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">42g / 70g</div>
            <p className="text-xs text-muted-foreground mt-2">28g remaining</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="meal-plan" className="space-y-4">
        <TabsList>
          <TabsTrigger value="meal-plan">Meal Plan</TabsTrigger>
          <TabsTrigger value="food-log">Food Log</TabsTrigger>
          <TabsTrigger value="recipes">Recipes</TabsTrigger>
        </TabsList>

        <TabsContent value="meal-plan" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Today's Meal Plan</CardTitle>
              <CardDescription>Personalized for your fitness goals</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <div className="bg-blue-100 p-2 rounded-full">
                      <Coffee className="h-5 w-5 text-blue-600" />
                    </div>
                    <h3 className="font-medium">Breakfast</h3>
                  </div>
                  <Badge variant="outline" className="text-blue-600 border-blue-200 bg-blue-50">
                    450 cal
                  </Badge>
                </div>

                <div className="pl-10 space-y-3">
                  <div className="flex items-start space-x-3">
                    <div className="w-16 h-16 rounded-md bg-gray-100 flex items-center justify-center">
                      <Apple className="h-8 w-8 text-gray-400" />
                    </div>
                    <div>
                      <h4 className="font-medium">Greek Yogurt with Berries and Granola</h4>
                      <div className="flex items-center space-x-4 mt-1 text-sm text-muted-foreground">
                        <div className="flex items-center">
                          <Clock className="h-3 w-3 mr-1" />
                          <span>10 min</span>
                        </div>
                        <div>Protein: 20g</div>
                        <div>Carbs: 45g</div>
                        <div>Fat: 15g</div>
                      </div>
                      <Button variant="link" size="sm" className="p-0 h-auto mt-1 text-blue-600">
                        View Recipe
                        <ArrowRight className="h-3 w-3 ml-1" />
                      </Button>
                    </div>
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <div className="bg-green-100 p-2 rounded-full">
                      <Utensils className="h-5 w-5 text-green-600" />
                    </div>
                    <h3 className="font-medium">Lunch</h3>
                  </div>
                  <Badge variant="outline" className="text-green-600 border-green-200 bg-green-50">
                    550 cal
                  </Badge>
                </div>

                <div className="pl-10 space-y-3">
                  <div className="flex items-start space-x-3">
                    <div className="w-16 h-16 rounded-md bg-gray-100 flex items-center justify-center">
                      <Utensils className="h-8 w-8 text-gray-400" />
                    </div>
                    <div>
                      <h4 className="font-medium">Grilled Chicken Salad with Quinoa</h4>
                      <div className="flex items-center space-x-4 mt-1 text-sm text-muted-foreground">
                        <div className="flex items-center">
                          <Clock className="h-3 w-3 mr-1" />
                          <span>20 min</span>
                        </div>
                        <div>Protein: 35g</div>
                        <div>Carbs: 40g</div>
                        <div>Fat: 18g</div>
                      </div>
                      <Button variant="link" size="sm" className="p-0 h-auto mt-1 text-blue-600">
                        View Recipe
                        <ArrowRight className="h-3 w-3 ml-1" />
                      </Button>
                    </div>
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <div className="bg-purple-100 p-2 rounded-full">
                      <Utensils className="h-5 w-5 text-purple-600" />
                    </div>
                    <h3 className="font-medium">Dinner</h3>
                  </div>
                  <Badge variant="outline" className="text-purple-600 border-purple-200 bg-purple-50">
                    650 cal
                  </Badge>
                </div>

                <div className="pl-10 space-y-3">
                  <div className="flex items-start space-x-3">
                    <div className="w-16 h-16 rounded-md bg-gray-100 flex items-center justify-center">
                      <Utensils className="h-8 w-8 text-gray-400" />
                    </div>
                    <div>
                      <h4 className="font-medium">Baked Salmon with Roasted Vegetables</h4>
                      <div className="flex items-center space-x-4 mt-1 text-sm text-muted-foreground">
                        <div className="flex items-center">
                          <Clock className="h-3 w-3 mr-1" />
                          <span>30 min</span>
                        </div>
                        <div>Protein: 40g</div>
                        <div>Carbs: 35g</div>
                        <div>Fat: 25g</div>
                      </div>
                      <Button variant="link" size="sm" className="p-0 h-auto mt-1 text-blue-600">
                        View Recipe
                        <ArrowRight className="h-3 w-3 ml-1" />
                      </Button>
                    </div>
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <div className="bg-orange-100 p-2 rounded-full">
                      <Apple className="h-5 w-5 text-orange-600" />
                    </div>
                    <h3 className="font-medium">Snacks</h3>
                  </div>
                  <Badge variant="outline" className="text-orange-600 border-orange-200 bg-orange-50">
                    300 cal
                  </Badge>
                </div>

                <div className="pl-10 space-y-3">
                  <div className="flex items-start space-x-3">
                    <div className="w-16 h-16 rounded-md bg-gray-100 flex items-center justify-center">
                      <Apple className="h-8 w-8 text-gray-400" />
                    </div>
                    <div>
                      <h4 className="font-medium">Protein Smoothie & Mixed Nuts</h4>
                      <div className="flex items-center space-x-4 mt-1 text-sm text-muted-foreground">
                        <div>Protein: 15g</div>
                        <div>Carbs: 25g</div>
                        <div>Fat: 12g</div>
                      </div>
                      <Button variant="link" size="sm" className="p-0 h-auto mt-1 text-blue-600">
                        View Recipe
                        <ArrowRight className="h-3 w-3 ml-1" />
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter className="border-t pt-4">
              <Button variant="outline" className="mr-2">
                Customize Plan
              </Button>
              <Button className="bg-blue-600 hover:bg-blue-700">Generate Shopping List</Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="food-log" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Today's Food Log</CardTitle>
              <CardDescription>Track your daily food intake</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="flex items-center space-x-3">
                    <div className="bg-blue-100 p-2 rounded-full">
                      <Coffee className="h-4 w-4 text-blue-600" />
                    </div>
                    <div>
                      <h4 className="font-medium">Greek Yogurt with Berries</h4>
                      <p className="text-xs text-muted-foreground">Breakfast - 8:30 AM</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-medium">450 cal</div>
                    <div className="text-xs text-muted-foreground">P: 20g | C: 45g | F: 15g</div>
                  </div>
                </div>

                <div className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="flex items-center space-x-3">
                    <div className="bg-green-100 p-2 rounded-full">
                      <Coffee className="h-4 w-4 text-green-600" />
                    </div>
                    <div>
                      <h4 className="font-medium">Protein Shake</h4>
                      <p className="text-xs text-muted-foreground">Snack - 11:00 AM</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-medium">180 cal</div>
                    <div className="text-xs text-muted-foreground">P: 25g | C: 10g | F: 3g</div>
                  </div>
                </div>

                <div className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="flex items-center space-x-3">
                    <div className="bg-purple-100 p-2 rounded-full">
                      <Utensils className="h-4 w-4 text-purple-600" />
                    </div>
                    <div>
                      <h4 className="font-medium">Grilled Chicken Salad</h4>
                      <p className="text-xs text-muted-foreground">Lunch - 1:15 PM</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-medium">550 cal</div>
                    <div className="text-xs text-muted-foreground">P: 35g | C: 40g | F: 18g</div>
                  </div>
                </div>

                <Button className="w-full">Add Food Item</Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="recipes" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            <Card>
              <CardHeader>
                <CardTitle>High Protein Breakfast Bowl</CardTitle>
                <CardDescription>Quick and nutritious</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center space-x-4 text-sm text-muted-foreground mb-4">
                  <div className="flex items-center">
                    <Clock className="h-4 w-4 mr-1" />
                    <span>15 min</span>
                  </div>
                  <div className="flex items-center">
                    <Flame className="h-4 w-4 mr-1" />
                    <span>420 cal</span>
                  </div>
                </div>
                <Button variant="outline" className="w-full">
                  View Recipe
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Protein-Packed Lunch Box</CardTitle>
                <CardDescription>Perfect for meal prep</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center space-x-4 text-sm text-muted-foreground mb-4">
                  <div className="flex items-center">
                    <Clock className="h-4 w-4 mr-1" />
                    <span>25 min</span>
                  </div>
                  <div className="flex items-center">
                    <Flame className="h-4 w-4 mr-1" />
                    <span>550 cal</span>
                  </div>
                </div>
                <Button variant="outline" className="w-full">
                  View Recipe
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Healthy Dinner Options</CardTitle>
                <CardDescription>Balanced and delicious</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center space-x-4 text-sm text-muted-foreground mb-4">
                  <div className="flex items-center">
                    <Clock className="h-4 w-4 mr-1" />
                    <span>30 min</span>
                  </div>
                  <div className="flex items-center">
                    <Flame className="h-4 w-4 mr-1" />
                    <span>650 cal</span>
                  </div>
                </div>
                <Button variant="outline" className="w-full">
                  View Recipe
                </Button>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
