import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { Award, Bell, Gift, Settings, User } from "lucide-react"

export default function Profile() {
  return (
    <div className="flex-1 space-y-4 p-4 md:p-8 pt-6">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold tracking-tight">Profile</h2>
        <div className="flex items-center space-x-2">
          <Button variant="outline">
            <Settings className="h-4 w-4 mr-2" />
            Settings
          </Button>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-7">
        <Card className="col-span-3">
          <CardHeader>
            <CardTitle>Personal Information</CardTitle>
            <CardDescription>Manage your profile details</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex flex-col items-center space-y-3">
              <div className="relative">
                <div className="h-24 w-24 rounded-full bg-blue-100 flex items-center justify-center">
                  <User className="h-12 w-12 text-blue-600" />
                </div>
                <Button size="sm" variant="outline" className="absolute bottom-0 right-0 rounded-full h-8 w-8 p-0">
                  <span className="sr-only">Edit avatar</span>
                  <Settings className="h-4 w-4" />
                </Button>
              </div>
              <div className="text-center">
                <h3 className="font-medium text-lg">John Smith</h3>
                <p className="text-sm text-muted-foreground">Member since May 2025</p>
              </div>
            </div>

            <div className="space-y-2">
              <div className="grid gap-1">
                <Label htmlFor="name">Full Name</Label>
                <Input id="name" defaultValue="John Smith" />
              </div>
              <div className="grid gap-1">
                <Label htmlFor="email">Email</Label>
                <Input id="email" defaultValue="john.smith@example.com" />
              </div>
              <div className="grid gap-1">
                <Label htmlFor="phone">Phone</Label>
                <Input id="phone" defaultValue="+1 (555) 123-4567" />
              </div>
            </div>
          </CardContent>
          <CardFooter>
            <Button className="w-full bg-blue-600 hover:bg-blue-700">Save Changes</Button>
          </CardFooter>
        </Card>

        <Card className="col-span-4">
          <CardHeader>
            <CardTitle>Fitness Profile</CardTitle>
            <CardDescription>Update your fitness information</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="height">Height</Label>
                <div className="flex space-x-2">
                  <Input id="height" defaultValue="5" />
                  <Input id="height-inches" defaultValue="10" />
                  <span className="flex items-center text-sm text-muted-foreground">ft/in</span>
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="weight">Weight</Label>
                <div className="flex space-x-2">
                  <Input id="weight" defaultValue="165" />
                  <span className="flex items-center text-sm text-muted-foreground">lbs</span>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="age">Age</Label>
                <Input id="age" defaultValue="32" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="gender">Gender</Label>
                <Select defaultValue="male">
                  <SelectTrigger id="gender">
                    <SelectValue placeholder="Select gender" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="male">Male</SelectItem>
                    <SelectItem value="female">Female</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                    <SelectItem value="prefer-not-to-say">Prefer not to say</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="goal">Fitness Goal</Label>
              <Select defaultValue="weight-loss">
                <SelectTrigger id="goal">
                  <SelectValue placeholder="Select goal" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="weight-loss">Weight Loss</SelectItem>
                  <SelectItem value="muscle-gain">Muscle Gain</SelectItem>
                  <SelectItem value="endurance">Improve Endurance</SelectItem>
                  <SelectItem value="general">General Fitness</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="activity">Activity Level</Label>
              <Select defaultValue="moderate">
                <SelectTrigger id="activity">
                  <SelectValue placeholder="Select activity level" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="sedentary">Sedentary (little or no exercise)</SelectItem>
                  <SelectItem value="light">Light (exercise 1-3 days/week)</SelectItem>
                  <SelectItem value="moderate">Moderate (exercise 3-5 days/week)</SelectItem>
                  <SelectItem value="active">Active (exercise 6-7 days/week)</SelectItem>
                  <SelectItem value="very-active">Very Active (intense exercise daily)</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
          <CardFooter>
            <Button className="w-full bg-blue-600 hover:bg-blue-700">Update Fitness Profile</Button>
          </CardFooter>
        </Card>
      </div>

      <Tabs defaultValue="achievements" className="space-y-4">
        <TabsList>
          <TabsTrigger value="achievements">Achievements</TabsTrigger>
          <TabsTrigger value="rewards-history">Rewards History</TabsTrigger>
          <TabsTrigger value="notifications">Notifications</TabsTrigger>
        </TabsList>

        <TabsContent value="achievements" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Your Achievements</CardTitle>
              <CardDescription>Track your fitness milestones</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-3">
                <div className="flex flex-col items-center p-4 border rounded-lg">
                  <div className="bg-blue-100 p-3 rounded-full mb-3">
                    <Award className="h-6 w-6 text-blue-600" />
                  </div>
                  <h3 className="font-medium text-center">Early Bird</h3>
                  <p className="text-sm text-center text-muted-foreground">Completed 5 workouts before 8 AM</p>
                </div>

                <div className="flex flex-col items-center p-4 border rounded-lg">
                  <div className="bg-green-100 p-3 rounded-full mb-3">
                    <Award className="h-6 w-6 text-green-600" />
                  </div>
                  <h3 className="font-medium text-center">Step Master</h3>
                  <p className="text-sm text-center text-muted-foreground">
                    Reached 10,000 steps for 7 consecutive days
                  </p>
                </div>

                <div className="flex flex-col items-center p-4 border rounded-lg">
                  <div className="bg-purple-100 p-3 rounded-full mb-3">
                    <Award className="h-6 w-6 text-purple-600" />
                  </div>
                  <h3 className="font-medium text-center">Workout Warrior</h3>
                  <p className="text-sm text-center text-muted-foreground">Completed 20 workouts in one month</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="rewards-history" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Rewards History</CardTitle>
              <CardDescription>Your earned and redeemed rewards</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="flex items-center space-x-4">
                    <div className="bg-blue-100 p-2 rounded-full">
                      <Gift className="h-5 w-5 text-blue-600" />
                    </div>
                    <div>
                      <h4 className="font-medium">Premium Membership</h4>
                      <p className="text-xs text-muted-foreground">Redeemed on May 1, 2025</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-medium">300 points</div>
                    <div className="text-xs text-green-600">Active until June 1, 2025</div>
                  </div>
                </div>

                <div className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="flex items-center space-x-4">
                    <div className="bg-green-100 p-2 rounded-full">
                      <Gift className="h-5 w-5 text-green-600" />
                    </div>
                    <div>
                      <h4 className="font-medium">Cash Reward</h4>
                      <p className="text-xs text-muted-foreground">Redeemed on April 15, 2025</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-medium">500 points</div>
                    <div className="text-xs text-green-600">₹100 Transferred</div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="notifications" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Notification Settings</CardTitle>
              <CardDescription>Manage how you receive notifications</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <Bell className="h-5 w-5 text-muted-foreground" />
                  <div>
                    <h4 className="font-medium">Workout Reminders</h4>
                    <p className="text-sm text-muted-foreground">Receive reminders for scheduled workouts</p>
                  </div>
                </div>
                <Switch defaultChecked />
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <Bell className="h-5 w-5 text-muted-foreground" />
                  <div>
                    <h4 className="font-medium">Achievement Alerts</h4>
                    <p className="text-sm text-muted-foreground">Get notified when you earn achievements</p>
                  </div>
                </div>
                <Switch defaultChecked />
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <Bell className="h-5 w-5 text-muted-foreground" />
                  <div>
                    <h4 className="font-medium">Reward Updates</h4>
                    <p className="text-sm text-muted-foreground">Notifications about new rewards and challenges</p>
                  </div>
                </div>
                <Switch defaultChecked />
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <Bell className="h-5 w-5 text-muted-foreground" />
                  <div>
                    <h4 className="font-medium">Email Notifications</h4>
                    <p className="text-sm text-muted-foreground">Receive updates via email</p>
                  </div>
                </div>
                <Switch />
              </div>
            </CardContent>
            <CardFooter>
              <Button className="w-full bg-blue-600 hover:bg-blue-700">Save Notification Preferences</Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
