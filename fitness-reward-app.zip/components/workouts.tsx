import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Dumbbell, Flame, Heart, Play, Timer, Zap } from "lucide-react"

export default function Workouts() {
  return (
    <div className="flex-1 space-y-4 p-4 md:p-8 pt-6">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold tracking-tight">Workouts</h2>
        <div className="flex items-center space-x-2">
          <Button className="bg-blue-600 hover:bg-blue-700">Start Workout</Button>
        </div>
      </div>

      <Tabs defaultValue="recommended" className="space-y-4">
        <TabsList>
          <TabsTrigger value="recommended">Recommended</TabsTrigger>
          <TabsTrigger value="strength">Strength</TabsTrigger>
          <TabsTrigger value="cardio">Cardio</TabsTrigger>
          <TabsTrigger value="flexibility">Flexibility</TabsTrigger>
        </TabsList>

        <TabsContent value="recommended" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {/* Today's Workout */}
            <Card className="col-span-full">
              <CardHeader className="bg-gradient-to-r from-blue-500 to-blue-600 text-white rounded-t-lg">
                <div className="flex justify-between items-center">
                  <CardTitle className="text-xl">Today's Workout</CardTitle>
                  <Badge variant="secondary" className="bg-white text-blue-600">
                    Recommended
                  </Badge>
                </div>
                <CardDescription className="text-blue-100">Personalized for your fitness goals</CardDescription>
              </CardHeader>
              <CardContent className="pt-6">
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="flex items-start space-x-4">
                    <div className="bg-blue-100 p-3 rounded-full">
                      <Dumbbell className="h-6 w-6 text-blue-600" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-lg">Upper Body Strength</h3>
                      <div className="flex items-center space-x-4 mt-2 text-sm text-muted-foreground">
                        <div className="flex items-center">
                          <Timer className="h-4 w-4 mr-1" />
                          <span>30 min</span>
                        </div>
                        <div className="flex items-center">
                          <Flame className="h-4 w-4 mr-1" />
                          <span>250 cal</span>
                        </div>
                        <div className="flex items-center">
                          <Zap className="h-4 w-4 mr-1" />
                          <span>Intermediate</span>
                        </div>
                      </div>
                      <p className="mt-3 text-sm">
                        Focus on building upper body strength with this comprehensive workout routine.
                      </p>
                    </div>
                  </div>

                  <div className="space-y-3">
                    <h4 className="font-medium">Exercises:</h4>
                    <ul className="space-y-2">
                      <li className="flex items-center text-sm">
                        <div className="bg-blue-100 p-1 rounded-full mr-2">
                          <span className="text-blue-600 text-xs font-medium px-1">1</span>
                        </div>
                        <span>Push-ups - 3 sets of 12 reps</span>
                      </li>
                      <li className="flex items-center text-sm">
                        <div className="bg-blue-100 p-1 rounded-full mr-2">
                          <span className="text-blue-600 text-xs font-medium px-1">2</span>
                        </div>
                        <span>Dumbbell rows - 3 sets of 10 reps</span>
                      </li>
                      <li className="flex items-center text-sm">
                        <div className="bg-blue-100 p-1 rounded-full mr-2">
                          <span className="text-blue-600 text-xs font-medium px-1">3</span>
                        </div>
                        <span>Shoulder press - 3 sets of 10 reps</span>
                      </li>
                      <li className="flex items-center text-sm">
                        <div className="bg-blue-100 p-1 rounded-full mr-2">
                          <span className="text-blue-600 text-xs font-medium px-1">4</span>
                        </div>
                        <span>Tricep dips - 3 sets of 12 reps</span>
                      </li>
                      <li className="flex items-center text-sm">
                        <div className="bg-blue-100 p-1 rounded-full mr-2">
                          <span className="text-blue-600 text-xs font-medium px-1">5</span>
                        </div>
                        <span>Bicep curls - 3 sets of 12 reps</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </CardContent>
              <CardFooter className="border-t pt-4">
                <Button variant="outline" className="mr-2">
                  View Details
                </Button>
                <Button className="bg-blue-600 hover:bg-blue-700">
                  <Play className="h-4 w-4 mr-2" />
                  Start Workout
                </Button>
              </CardFooter>
            </Card>

            {/* Other Recommended Workouts */}
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle>Lower Body Strength</CardTitle>
                  <Badge variant="outline" className="text-blue-600 border-blue-200 bg-blue-50">
                    +25 pts
                  </Badge>
                </div>
                <CardDescription>Build leg strength and stability</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center space-x-4 text-sm text-muted-foreground mb-4">
                  <div className="flex items-center">
                    <Timer className="h-4 w-4 mr-1" />
                    <span>35 min</span>
                  </div>
                  <div className="flex items-center">
                    <Flame className="h-4 w-4 mr-1" />
                    <span>280 cal</span>
                  </div>
                  <div className="flex items-center">
                    <Zap className="h-4 w-4 mr-1" />
                    <span>Intermediate</span>
                  </div>
                </div>
                <ul className="space-y-1 text-sm">
                  <li className="flex items-center">
                    <div className="w-1 h-1 rounded-full bg-muted-foreground mr-2"></div>
                    <span>Squats - 4 sets</span>
                  </li>
                  <li className="flex items-center">
                    <div className="w-1 h-1 rounded-full bg-muted-foreground mr-2"></div>
                    <span>Lunges - 3 sets</span>
                  </li>
                  <li className="flex items-center">
                    <div className="w-1 h-1 rounded-full bg-muted-foreground mr-2"></div>
                    <span>Leg press - 3 sets</span>
                  </li>
                  <li className="flex items-center">
                    <div className="w-1 h-1 rounded-full bg-muted-foreground mr-2"></div>
                    <span>Calf raises - 4 sets</span>
                  </li>
                </ul>
              </CardContent>
              <CardFooter className="border-t pt-4">
                <Button variant="outline" className="w-full">
                  View Workout
                </Button>
              </CardFooter>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle>HIIT Cardio</CardTitle>
                  <Badge variant="outline" className="text-blue-600 border-blue-200 bg-blue-50">
                    +30 pts
                  </Badge>
                </div>
                <CardDescription>High intensity interval training</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center space-x-4 text-sm text-muted-foreground mb-4">
                  <div className="flex items-center">
                    <Timer className="h-4 w-4 mr-1" />
                    <span>25 min</span>
                  </div>
                  <div className="flex items-center">
                    <Flame className="h-4 w-4 mr-1" />
                    <span>320 cal</span>
                  </div>
                  <div className="flex items-center">
                    <Zap className="h-4 w-4 mr-1" />
                    <span>Advanced</span>
                  </div>
                </div>
                <ul className="space-y-1 text-sm">
                  <li className="flex items-center">
                    <div className="w-1 h-1 rounded-full bg-muted-foreground mr-2"></div>
                    <span>Burpees - 45 sec</span>
                  </li>
                  <li className="flex items-center">
                    <div className="w-1 h-1 rounded-full bg-muted-foreground mr-2"></div>
                    <span>Mountain climbers - 45 sec</span>
                  </li>
                  <li className="flex items-center">
                    <div className="w-1 h-1 rounded-full bg-muted-foreground mr-2"></div>
                    <span>Jump squats - 45 sec</span>
                  </li>
                  <li className="flex items-center">
                    <div className="w-1 h-1 rounded-full bg-muted-foreground mr-2"></div>
                    <span>High knees - 45 sec</span>
                  </li>
                </ul>
              </CardContent>
              <CardFooter className="border-t pt-4">
                <Button variant="outline" className="w-full">
                  View Workout
                </Button>
              </CardFooter>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle>Core Strength</CardTitle>
                  <Badge variant="outline" className="text-blue-600 border-blue-200 bg-blue-50">
                    +20 pts
                  </Badge>
                </div>
                <CardDescription>Build a strong core and abs</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center space-x-4 text-sm text-muted-foreground mb-4">
                  <div className="flex items-center">
                    <Timer className="h-4 w-4 mr-1" />
                    <span>20 min</span>
                  </div>
                  <div className="flex items-center">
                    <Flame className="h-4 w-4 mr-1" />
                    <span>180 cal</span>
                  </div>
                  <div className="flex items-center">
                    <Zap className="h-4 w-4 mr-1" />
                    <span>Beginner</span>
                  </div>
                </div>
                <ul className="space-y-1 text-sm">
                  <li className="flex items-center">
                    <div className="w-1 h-1 rounded-full bg-muted-foreground mr-2"></div>
                    <span>Planks - 3 sets</span>
                  </li>
                  <li className="flex items-center">
                    <div className="w-1 h-1 rounded-full bg-muted-foreground mr-2"></div>
                    <span>Crunches - 3 sets</span>
                  </li>
                  <li className="flex items-center">
                    <div className="w-1 h-1 rounded-full bg-muted-foreground mr-2"></div>
                    <span>Russian twists - 3 sets</span>
                  </li>
                  <li className="flex items-center">
                    <div className="w-1 h-1 rounded-full bg-muted-foreground mr-2"></div>
                    <span>Leg raises - 3 sets</span>
                  </li>
                </ul>
              </CardContent>
              <CardFooter className="border-t pt-4">
                <Button variant="outline" className="w-full">
                  View Workout
                </Button>
              </CardFooter>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="strength">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            <Card>
              <CardHeader>
                <CardTitle>Full Body Strength</CardTitle>
                <CardDescription>Complete body workout</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center space-x-4 text-sm text-muted-foreground mb-4">
                  <div className="flex items-center">
                    <Timer className="h-4 w-4 mr-1" />
                    <span>45 min</span>
                  </div>
                  <div className="flex items-center">
                    <Flame className="h-4 w-4 mr-1" />
                    <span>350 cal</span>
                  </div>
                </div>
                <Button variant="outline" className="w-full">
                  View Workout
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Upper Body Focus</CardTitle>
                <CardDescription>Arms, chest and back</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center space-x-4 text-sm text-muted-foreground mb-4">
                  <div className="flex items-center">
                    <Timer className="h-4 w-4 mr-1" />
                    <span>30 min</span>
                  </div>
                  <div className="flex items-center">
                    <Flame className="h-4 w-4 mr-1" />
                    <span>250 cal</span>
                  </div>
                </div>
                <Button variant="outline" className="w-full">
                  View Workout
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Lower Body Focus</CardTitle>
                <CardDescription>Legs and glutes</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center space-x-4 text-sm text-muted-foreground mb-4">
                  <div className="flex items-center">
                    <Timer className="h-4 w-4 mr-1" />
                    <span>35 min</span>
                  </div>
                  <div className="flex items-center">
                    <Flame className="h-4 w-4 mr-1" />
                    <span>280 cal</span>
                  </div>
                </div>
                <Button variant="outline" className="w-full">
                  View Workout
                </Button>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="cardio">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            <Card>
              <CardHeader>
                <CardTitle>HIIT Cardio</CardTitle>
                <CardDescription>High intensity intervals</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center space-x-4 text-sm text-muted-foreground mb-4">
                  <div className="flex items-center">
                    <Timer className="h-4 w-4 mr-1" />
                    <span>25 min</span>
                  </div>
                  <div className="flex items-center">
                    <Flame className="h-4 w-4 mr-1" />
                    <span>320 cal</span>
                  </div>
                </div>
                <Button variant="outline" className="w-full">
                  View Workout
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Steady State Cardio</CardTitle>
                <CardDescription>Endurance building</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center space-x-4 text-sm text-muted-foreground mb-4">
                  <div className="flex items-center">
                    <Timer className="h-4 w-4 mr-1" />
                    <span>40 min</span>
                  </div>
                  <div className="flex items-center">
                    <Flame className="h-4 w-4 mr-1" />
                    <span>300 cal</span>
                  </div>
                </div>
                <Button variant="outline" className="w-full">
                  View Workout
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Tabata</CardTitle>
                <CardDescription>20 seconds on, 10 seconds off</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center space-x-4 text-sm text-muted-foreground mb-4">
                  <div className="flex items-center">
                    <Timer className="h-4 w-4 mr-1" />
                    <span>20 min</span>
                  </div>
                  <div className="flex items-center">
                    <Flame className="h-4 w-4 mr-1" />
                    <span>250 cal</span>
                  </div>
                </div>
                <Button variant="outline" className="w-full">
                  View Workout
                </Button>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="flexibility">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            <Card>
              <CardHeader>
                <CardTitle>Yoga Flow</CardTitle>
                <CardDescription>Improve flexibility and balance</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center space-x-4 text-sm text-muted-foreground mb-4">
                  <div className="flex items-center">
                    <Timer className="h-4 w-4 mr-1" />
                    <span>30 min</span>
                  </div>
                  <div className="flex items-center">
                    <Heart className="h-4 w-4 mr-1" />
                    <span>Low impact</span>
                  </div>
                </div>
                <Button variant="outline" className="w-full">
                  View Workout
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Stretching Routine</CardTitle>
                <CardDescription>Full body flexibility</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center space-x-4 text-sm text-muted-foreground mb-4">
                  <div className="flex items-center">
                    <Timer className="h-4 w-4 mr-1" />
                    <span>20 min</span>
                  </div>
                  <div className="flex items-center">
                    <Heart className="h-4 w-4 mr-1" />
                    <span>Low impact</span>
                  </div>
                </div>
                <Button variant="outline" className="w-full">
                  View Workout
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Pilates</CardTitle>
                <CardDescription>Core strength and flexibility</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center space-x-4 text-sm text-muted-foreground mb-4">
                  <div className="flex items-center">
                    <Timer className="h-4 w-4 mr-1" />
                    <span>25 min</span>
                  </div>
                  <div className="flex items-center">
                    <Heart className="h-4 w-4 mr-1" />
                    <span>Medium impact</span>
                  </div>
                </div>
                <Button variant="outline" className="w-full">
                  View Workout
                </Button>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
