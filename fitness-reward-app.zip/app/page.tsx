import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import Dashboard from "@/components/dashboard"
import Workouts from "@/components/workouts"
import Nutrition from "@/components/nutrition"
import Rewards from "@/components/rewards"
import Profile from "@/components/profile"
import { MobileNav } from "@/components/mobile-nav"

export default function Home() {
  return (
    <main className="flex min-h-screen flex-col bg-white">
      <div className="hidden md:block">
        <Tabs defaultValue="dashboard" className="w-full">
          <div className="border-b">
            <div className="flex h-16 items-center px-4">
              <div className="flex items-center">
                <span className="text-2xl font-bold text-blue-600">FitRewards</span>
              </div>
              <TabsList className="ml-auto">
                <TabsTrigger value="dashboard">Dashboard</TabsTrigger>
                <TabsTrigger value="workouts">Workouts</TabsTrigger>
                <TabsTrigger value="nutrition">Nutrition</TabsTrigger>
                <TabsTrigger value="rewards">Rewards</TabsTrigger>
                <TabsTrigger value="profile">Profile</TabsTrigger>
              </TabsList>
            </div>
          </div>
          <TabsContent value="dashboard" className="p-0">
            <Dashboard />
          </TabsContent>
          <TabsContent value="workouts" className="p-0">
            <Workouts />
          </TabsContent>
          <TabsContent value="nutrition" className="p-0">
            <Nutrition />
          </TabsContent>
          <TabsContent value="rewards" className="p-0">
            <Rewards />
          </TabsContent>
          <TabsContent value="profile" className="p-0">
            <Profile />
          </TabsContent>
        </Tabs>
      </div>

      {/* Mobile view */}
      <div className="md:hidden">
        <div className="border-b">
          <div className="flex h-16 items-center px-4">
            <span className="text-2xl font-bold text-blue-600">FitRewards</span>
          </div>
        </div>
        <Dashboard />
        <MobileNav />
      </div>
    </main>
  )
}
